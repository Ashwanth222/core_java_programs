package TestCode;

public class SumOfArray {
	
	public static void main(String[] args) {
		
		int sum=0;
		
		int arr[] = {2, 6, 4, 6} ;
		
		int n = arr.length;
		
		for (int i = 0; i<n; i++) {
			
			
			sum = sum + arr[i];
						
		}
		System.out.println(sum);
	}

}

package TestCode;

public class TwoTable {
	
	public static void main(String[] args) {
		
	
	
	int n = 3;
	int n1;
	int s=11;
	
	for(int i=1; i<s; i++) {
		
		 n1= n*i;
		
		
		System.out.println(n1);
	}

	}
		
		
		
	}



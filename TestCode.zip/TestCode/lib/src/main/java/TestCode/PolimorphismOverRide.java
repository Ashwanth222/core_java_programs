package TestCode;

	



public class PolimorphismOverRide {
	
	
	public static class One {
		
		
		void calculate(int n){
			System.out.println("Square = "+ (n*n));
		}
	}


	public static class Two extends One {
		
		
		void calculate(int n){
			System.out.println("Square root = " + Math.sqrt(n));
		}

		
	}
	

	public static void main(String[] args) {
		System.out.println("Hi");
		
		
		Two x = new Two();
		x.calculate(8);
	}
	
	

}

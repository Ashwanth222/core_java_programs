package TestCode;

public class SumOfTenNum {
	
	public static void main(String[] args) {
		
		int sum =0;
		
		for(int i=0; i<10; i++) {
			
			sum= sum+i;
		}
			int sum1 = sum;
			
			System.out.println(sum1);
		
	}

}

package TestCode;

public class ExceptionHandlingDemo {
	public static void main(String[] args) {
		System.out.println("main method starts....................");
		ExceptionHandlingDemo obj = new ExceptionHandlingDemo();
		try{
			int a = Integer.parseInt(args[5]);
			obj.calculate(a);
		}catch(ArrayIndexOutOfBoundsException e1){
			e1.printStackTrace();
		}catch(ArithmeticException  e2){
			e2.printStackTrace();
		}finally{
			System.out.println("Inside FInally Block");
		}
		System.out.println("main method ends");
	}
	private void calculate(int a) {
		int x = 36 / a;
		System.out.println(x);
	}
}

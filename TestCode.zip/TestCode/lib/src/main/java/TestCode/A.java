package TestCode;

 class A1 {
	public A1(){
		System.out.println("A class Constructor");
	}
	public void method1(){
		System.out.println("A class method1()");
	}
}

 class B extends A1{
	public B(){
		System.out.println("B class Constructor");
	}
	public void method2(){
		System.out.println("B class method2()");
	}

}

public class A {
	public static void main(String[] args) {
		B obj =  new B();
		// the default constructor of sub class internally calls the
		//default constructor of its super class.
		Obj.method1(); // calling super class method
		Obj.method2();  // calling sub class method
	}
}




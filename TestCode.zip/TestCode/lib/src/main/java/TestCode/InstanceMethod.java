package TestCode;

public class InstanceMethod {
	
	
		// instance variable or properties
		String name;
		int age;
		 String gender;     
		//constructor
		 InstanceMethod(String nam,int ag,String gen){
			this.name = nam;
			this.age = ag;
			this.gender = gen;
		}  
		public void display(){
			System.out.println("Name : " + name);
			System.out.println("Age : " + age);
			System.out.println("Gender " + gender);
		}



		public static void main(String[] args) {
			InstanceMethod p1 = new InstanceMethod("Reddy", 30, "Male");
		p1.display();
		}
}




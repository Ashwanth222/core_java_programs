package TestCode;

import java.io.*;
import java.util.Scanner;

public class ReverseString {
	
	// java program to reverse a word

	
	//class GFG {
		public static void main (String[] args) {
			
			String str= "Geeks";
					String nstr="";
			char ch;
			int n=str.length();
			
		System.out.print("Original word: ");
		System.out.println("Geeks"); //Example word
			
		for (int i=n-1; i>=0; i--)
		{
			ch= str.charAt(i); //extracts each character
			nstr= nstr+ch;
			//adds each character in front of the existing string
		}
		System.out.println("Reversed word: "+ nstr);
		}
	}


	//Contributed by Tiyasa




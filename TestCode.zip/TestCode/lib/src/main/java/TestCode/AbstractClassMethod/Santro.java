package TestCode.AbstractClassMethod;

public class Santro extends Car {
	Santro(int r) {
		super(r);
	}
	@Override
	public void steering() {
		System.out.println("Hydraulic Steering");
	}
	@Override
	public void breaking() {
		System.out.println("Hydraulic breaks");
	}
	public void displayDetails(){
		System.out.println("this is Santro car");
	}
}
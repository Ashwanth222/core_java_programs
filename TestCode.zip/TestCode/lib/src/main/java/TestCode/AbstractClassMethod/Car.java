package TestCode.AbstractClassMethod;


public abstract class Car {
	int regNo;
	int carNo;
	Car(int r ){
		regNo = r;
	 
	}
	
	Car(int r,int e){
		regNo = r;
		carNo = e;
	}
	public void fillTank(int regNo){
		System.out.println("Take key ,open tank and fill Oil"  + regNo);
		System.out.println("Maruthi car  no:"  + carNo);
		
	}
	public abstract void steering();
	public abstract void breaking();
}








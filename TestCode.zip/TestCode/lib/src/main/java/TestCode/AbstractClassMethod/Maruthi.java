package TestCode.AbstractClassMethod;

public class Maruthi extends Car {
	Maruthi(int r, int e) {
		super(r,e);
	}
//	@Override
//	public void fillTank(){
//		System.out.println("Take key ,open tank and fill Oil maruthi");
//	}
	@Override
	public void steering() {
		System.out.println("Manual Steering");
	}
	@Override
	public void breaking() {
		System.out.println("Gas breaks");
	}
	public void displayDetails(){
		System.out.println("this is Maruthi car");
	}
}
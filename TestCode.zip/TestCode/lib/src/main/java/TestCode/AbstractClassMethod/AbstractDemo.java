package TestCode.AbstractClassMethod;

public class AbstractDemo {
	public static void main(String[] args) {
//		Maruthi m = new Maruthi(1001);
//		Santro s = new Santro(1002);
//		//Car ref;
		//ref = m;
		
		
		Car ref = new Maruthi(1001,3001);
		Car ref1= new Santro(1002);

		
		ref.fillTank(2001);
		ref.steering();
		ref.breaking();

		//ref = s;
		ref1.fillTank(2002);
		ref1.steering();
		ref1.breaking();	
	}
}
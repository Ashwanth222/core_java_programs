package TestCode;

public class SmallestNumNew {

	SmallestNumInArray s = new SmallestNumInArray();
	
	s.
}

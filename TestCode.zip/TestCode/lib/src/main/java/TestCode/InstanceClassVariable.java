package TestCode;
import TestCode.SmallestNumInArray;


public class InstanceClassVariable {
	
	 int myVariable;
	   static int data = 30;
	   
	   public static void main(String args[]){
		   SmallestNumInArray s = new SmallestNumInArray();
		   //InstanceClassVariable obj = new InstanceClassVariable();
		   
			int a[]={7,8,2,4,5,6,4,3,5};

	      
		      System.out.println("Value of instance variable: "+ SmallestNumInArray.getSmallest(a, 9)); 
		      
		      System.out.println("Value of instance variable: "+ s.getSmallest(a, 9));

	    //  System.out.println("Value of instance variable: "+obj.myVariable);
	    //  System.out.println("Value of static variable: "+InstanceClassVariable.data);
	   }

}

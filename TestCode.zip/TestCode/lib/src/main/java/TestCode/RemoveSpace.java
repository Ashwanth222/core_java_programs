package TestCode;
import java.io.*;
public class RemoveSpace {
	
	
	
	   public static void main(String args[]) {
	      String str = new String(" Jack Sparrow ");
	      System.out.println("String: "+str);
	      System.out.print("Result after removing leading and trailing spaces:" );
	      System.out.println(str.trim() );
	   }
	}



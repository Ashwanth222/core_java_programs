package TestCode;

public class NewReverseString {
	
	public static void main(String[] args) {
	
//		String str ="Ashwanth";
//		
//		String nstr ="";
//		
//		int n = str.length();
//		
//		for (int i=n-1; i>=0; i--) {
//			
//			char ch = str.charAt(i);
//			
//			nstr = nstr + ch;
//			
//		}
//		System.out.println(nstr);
		
		//--------------------------------------------------
		
//		int num1 = 4;
//		int num2 = 88;
//		int num3 = 6;
//		int num4 =52;
//		
//		
//		
//		if (num1>num2 & num1>num3 &num1>num4) {
//			
//			
//			System.out.println(num1);
//		
//			
//		}else if (num2>num1 & num2>num3 & num2>num4) {
//			
//			System.out.println(num2);
//			
//		}	
//			else if (num3>num1 & num3>num2 &num3>num4) {
//				
//				System.out.println(num3);
//		}	else {
//			
//			System.out.println(num4);
//		}
		
		
//		int a = 3;
////		int b =4;
////		int c = 6;
//		int n;
//		
//		if (a%2==0) {
//			
//			System.out.println(a + " is even num");
//		}else {
//		
//			System.out.println(a + " is odd num");
//		}
		
//		int arr[] = {1,2,3,4,5,6};
//		
//		
//		
//	int	n =arr.length;
//		
//		for (int i=0; i<n; i++) {
//			
//			if (arr[i]==6) {
//			
//			System.out.println("true" + arr[i]);
//			}
//		}
		
		//--------------------------------------------------
		
//		String str = "hayah";
//		String nnstr ="";
//		
//		int nstr = str.length();
//		
//		for(int i=nstr-1; i>=0; i--) {
//			
//			nnstr = nnstr+str.charAt(i);
//		}
//			
//			if(str.equals(nnstr)) {
//				
//				System.out.println("It is polindrome");
//			}else {
//				System.out.println("Not a polindrome");
//			}
			
		
//		int arr[]= {2,7,4,1};
//		
//	    int str = arr.length;
//	    int temp=0;
//	    
//	    for (int i=0; i<str; i++) {
//	    	for (int j=i+1; j<str; j++) {
//	    	
//	    	if(arr[i]>arr[j]) {
//	    		
//	    		temp = arr[i];
//	    		arr[i]=arr[j];
//	    		arr[j]=temp;
//	    		//System.out.println(arr[i]);
//	    		
//	    	}
//	    	}
//	    //	System.out.println(arr[i]);
//	    
//	    }
//	    for (int i=0; i<str; i++) {
//	    	System.out.println(arr[i]);
//	    }
		
			
		
		
		
	}


}

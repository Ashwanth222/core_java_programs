package TestCode;

public class GlobelVariableLocalVariable {
	
	int b = 5;
	
	
	public int getSmallestNumber(int a) {
		
		System.out.println(b);
		return a;
		
		
	}
	
public int getSmallestNumbers1(int a) {
		int c = 7;
		System.out.println(c);
		System.out.println(b);
		return a;
		
		
	}
	
	
	
	public static void main(String[] args) {
		
		GlobelVariableLocalVariable b = new GlobelVariableLocalVariable();
		
		int a = 10;
		
		System.out.println(b.getSmallestNumber(a));
		System.out.println(b.getSmallestNumbers1(a));
		
		
	}

}

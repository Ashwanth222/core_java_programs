package TestCode;

public class Polimorphism {
	
	
			
		public static void main(String[] args) {
			Polimorphism c = new Polimorphism();
			c.sum(10,20);
			c.sum(10,20,30);
			c.sum(2.0f,6);
			c.sum(4,20.01,6);
			c.sum(5, 7.00,6666666l);
			c.sum(55.2,66.2,8);
			
		}
		
		void sum(int a, int b){
			System.out.println("Sum of two numbers = " + (a+b));
		}
		void sum(int a, int b,int c){
			System.out.println("Sum of three numbers = " + (a+b+c));
		}
		
		void sum(float a, int b){
			System.out.println("Sum of two numbers1 = " + (a+b));
		}
		void sum(int a, double b,int c){
			System.out.println("Sum of three numbers2 = " + (a+b+c));
		}
		void sum(int a, double b,long c){
			System.out.println("Sum of three numbers3 = " + (a+b+c));
			//System.out.println("hai");
		}
		void sum(double a, double b,int c){
			System.out.println("Sum of three numbers4 = " + (a+b+c));
		}
}




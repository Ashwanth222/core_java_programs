package TestCode;

public class MergeTwoLists {

	
	public static void main(String[] args) {
		
		int arr[] = {2, 4, 6};
		int arr2[] = {3, 7, 9, 8};
		int arr3[] = null;
		
		int n = arr.length;
		int m = arr2.length;
				
		
		for (int i=4; i<8; i++) {
			
			arr2 = arr2 + arr[i];
		}
	}
}

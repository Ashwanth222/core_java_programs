package TestCode;

public class LargestNum {
	
	public static void main(String[] args) {
		
		int x, y, z;
        
        x = 2;
       
        y = 4;
        
        z = 6;
        if(x > y && x > z)
        {
            System.out.println("Largest number is:"+x);
        }
        else if(y > z)
        {
            System.out.println("Largest number is:"+y);
        }
        else
        {
            System.out.println("Largest number is:"+z);
        }
 
    
	}

}

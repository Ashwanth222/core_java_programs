package TestCode.Inheritance;

public class A {
	
	
		public A(){
			System.out.println("A class Constructor");
		}
		public void method1(){
			System.out.println("A class method1()");
		}



}

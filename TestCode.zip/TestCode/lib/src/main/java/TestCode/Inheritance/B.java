package TestCode.Inheritance;

public class B extends A{
	public B(){
		System.out.println("B class Constructor");
	}
	public void method2(){
		System.out.println("B class method2()");
	}
	
	public void method1(){
		System.out.println("b class method1()");
	}

}

package TestCode.Inheritance;

public class C {
	public C(){
		System.out.println("C class Constructor");
	}
	public void method3(){
		System.out.println("C class method3()");
	}

}

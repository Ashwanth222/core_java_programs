package TestCode.Inheritance;

public class InheritanceDemo {

	
	public static void main(String[] args) {
		B obj =  new B();
		// the default constructor of sub class internally calls the
		//default constructor of its super class.
		obj.method1(); // calling super class method
		//obj.method3();  // calling sub class method
		obj.method2();  // calling sub class method
	}

}
